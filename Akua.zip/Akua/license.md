✪ SCRIPT INI FREE DAN TIDAK UNTUK DJUAL BELIKAN 
✪ APABILA ADA YANG MENJUAL SCRIPT INI DI KENAKAN DENDA 50K
✪ BEBAS RENAME DAN UNTUK DI KEMBANGKAN 
✪ JANGAN HAPUS CREDIT AUTHOR DEVELOPER 
✪ JIKA ADA KENDALA SILAHKAN LAPOR KE DEVELOPER 
✪ APABILA ADA REQUEST FITUR BISA LANGSUNG HUBUNGI DEVELOPER 
✪ JIKA INGIN MEMBELI APIKEY , SCRIPT PREMIUM V3 

CONTACT PERSON : 
WHATSAPP: 6285196895485 ( SATAN)
TELEGRAM: t.me/Fourttwentyonezero
LIVECHAT: https://free-restapi.biz.id/livechat
FORUM: https://free-restapi.biz.id/forum

jika selain ini diatas clone yaa ^_^
- admin tidak bertanggung jawab jika ada transaksi diluar tanggung jawab admin
- admin tanggung jawab apabila ada transaksi dengan admin, sertakan bukti yang lengkap 
